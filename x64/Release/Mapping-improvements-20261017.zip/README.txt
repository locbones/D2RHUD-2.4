Mapping improvements - October 17, 2026

1. Fully close D2R and replace d2rhud.dll in the D2R directory.
2. Every TCP/IP player needs this same DLL. Relaunch with the normal mod options.
3. The sample TSV contains a header and ONE recipe row. Copy it into your
   existing cubemain.txt; do not replace the whole table with the sample.
   Existing useitem,map=<level> recipes with regular item outputs now work.
4. Launch with -txt after changing your recipe table.

Map portals close when everyone in town at entry has arrived. New recipes
reroll the destination's per-level seed and room graph. Act III jungle river
and clearing paths also reroll, keeping connected native tiles, exterior exits,
head/tail rows, bounds and clearing counts. Fixed layouts retain native limits.
Jungle templates are deterministic on host and client; layout protocol version
3 prevents older HUD builds from acknowledging a different terrain layout.

After a clear, the normal monster population returns when the destination is
unoccupied. An unfinished ordinary map may be replaced from town after everyone
has left its area. Active special events must finish before another recipe.
Existing ground items are preserved through town relocation. Cleanup does not
populate unused areas or generate extra gold to relocate.

Room regeneration clears neighboring caches and native status links before
freeing old geometry. map-events.log includes server/client seeds, room rectangle
hashes and jungle-template hashes. Outdoor room rectangles can remain identical
while river paths change; compare the jungle hash for those areas.
See cube-maps.md for details.

No launcher, D2R.exe or character save format changes are required.
DLL SHA256: D40EB59A59E3A60E7D966910B5D5E084409682833BE067055BDCF8CE1749EBC8
