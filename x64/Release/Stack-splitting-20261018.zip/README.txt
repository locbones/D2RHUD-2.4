D2RHUD: Compact quantity popup and offline Restart Game

Fully close D2R before replacing d2rhud.dll. Keep launcher Disable update checks
on for local HUD builds.

Quantity Right-Clicks is in D2RHUD Options and defaults to on.
Right-click a non-transmog stack: one item is split to free storage, and a tiny
gothic quantity panel appears above the clicked item. Use up/down arrows or click the number,
then Split or Enter. Choosing 20 from 88 leaves 68 + 20.
The panel has no dim layer and takes no automatic keyboard focus.
Clicking outside dismisses it and passes the click to the game.
Closing the panel keeps the initial one-item split; full storage changes nothing.

Restart Game is hidden and disabled for TCP/IP hosts and joining clients,
including a host with only one player. It remains available offline.
Its existing pause-menu layout edits must still be installed for the offline button.

Native regression, popup layout/input, and Release-build checks pass.
No game EXE, launcher, recipe/item-table or save-format changes are required.

Quantity panel: visual Keep -> New stack item preview, with both quantities. Approximately 307 x 213 at 1080p.

D2RHUD Options > Quantity Right-Clicks > Minimalist Quantity Popup restores the compact 281 x 114 layout without item images. Defaults off; saves immediately. Both layouts retain the 30% text/control enlargement.
