Mapping variety - October 18, 2026

Fully close D2R and replace d2rhud.dll in the D2R directory. Every TCP/IP player
needs this same DLL. Relaunch using your normal mod options.

Use map=zzz or useitem,map=zzz for a random eligible destination. Random maps
exclude all Torment Trials, Icy Hell, Uber Tristram and Forest Ruins, as well as
towns, empty populations and unusable geometry. Numeric map=<level ID> recipes
retain their existing behavior. Each transmute makes a new selection.

The two sample TSVs each contain a header and ONE recipe row. Choose the fixed
or random identify-scroll example and copy its row into existing cubemain.txt.
Do not replace the full recipe table or add both identical-input examples.
Restart with -txt after editing cubemain.txt. No recipe table is installed by
this package.

Ordinary maps have 8-13 champion/unique packs; existing named packs count toward
the total. Champion groups count once. Maps unable to place complete packs
refuse before consuming ingredients. Special events and normal restoration
retain their own population rules.

New random conditions: Treasure Surge (+1-3 root TC picks), additional monster
levels (+2-6), Glass Cannon, Battle Frenzy, Blood Feast, Second Wind, Fleet
Footed, Featherweights and Heavy Hitters. Extra loot rolls retain native quality,
NoDrop, nested classes and difficulty upgrades. Paired themes cannot roll with
conflicting stats on the same side. All effects are scoped to the active map.
See cube-maps.md for exact ranges and behavior.

This includes the earlier lenient recipes, portal-party closure, repeated level
regeneration, jungle-path rerolls, room-cache crash fix and ordinary population
restoration. Map snapshot/command protocol version 4 requires matching HUDs.

Build, native population/loot/geometry regressions, recipe adapters and UI tests
pass. Live in-game verification is still required.

No launcher, D2R.exe, global treasure tables or character save formats changed.
DLL SHA256: E34AF284F765B94CE86E0DFDB4747159285DFCA031BC65241A0FBAE350A82BB9
