D2RHUD map event update - 2026-10-18

Close D2R completely and replace d2rhud.dll beside D2R.exe. All multiplayer participants need this build and matching mod tables.

Add the ChampClash row from champ-clash-treasureclass.tsv to your mod's TreasureClassEx.txt, matching that file's header columns. This is a single-row fragment, NOT a replacement for the full file. If the row already exists, do not duplicate it. Initial contents: Picks=1, NoDrop=0, Item1=TormentGroupA, Prob1=1. Customize later as desired. TormentGroupA must already exist. Relaunch the mod with -txt after editing to rebuild its compiled tables.

Trials of Tribulation keeps a 5% chance. The other 95% selects equally among Goblin Grotto (Cow Level, 60 seconds), Treasure Trove (+500% set/unique chance, 10 minutes anywhere), Golden Goose (+500% gold amount, 10 minutes anywhere), Champion Clash (elite packs in Chaos Sanctuary, no timer, ChampClash drops), Plentiful Pirating (NoDrop=0 and +1 Picks at every visited TC, 10 minutes anywhere), and Soul Surprise (level 239, 60 seconds).

Location-free bonuses coexist and repeat rewards refresh their own duration. All other event random monsters use TormentGroupA. See cube-maps.md for details. Existing character save formats are unchanged. This package contains no launcher or game executable edits.

Validation: native cube/map/loot/population and automap regression suites, including the actual supported executable's relocated native paths; event lifecycle, reward ownership/expiry and client packet checks; HUD bounds/timers at 720p and 4K. In-game playtesting of the new event rotation is still needed.
DLL SHA256: 01D5E363ED9102881921E2273A0FD9A39C9CEEBE4813BA1AF599473CF235AF85

Blank correction: During Plentiful Pirating all references to the Blank treasure class have zero probability weight, at the root and every nested TC. Remaining valid drop weights retain their relative probabilities. Ordinary drops keep Blank unchanged.

Assassin restart update: Includes the colleague's ordinary Assassin Whirlwind animation fix while D3 Style Whirlwind is off, integrated into the current full source build. Existing gold pickup and Terror Zone rotation are retained. Full restart required; test ordinary Assassin Whirlwind with the D3 option disabled. Native success/path-failure and scope/restoration tests pass; live animation still needs checking. See d3-whirlwind.md.
