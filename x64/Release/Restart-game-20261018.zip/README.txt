D2RHUD Restart Game - offline loader/click-route fix - 2026-10-18

Close D2R fully before replacing d2rhud.dll beside D2R.exe.
Copy mod/RMD-MP.mpq contents into your unpacked RMD-MP.mpq folder.
The pause layouts and theme variants must be updated as well as the DLL.
For a different unpacked mod, run tools/add-restart-game-button.py against its .mpq folder. The script also upgrades the previous restart-button action without adding another row.
Keep the launcher's existing Disable update checks option enabled for local HUD builds.

Restart Game saves and follows normal exit/cleanup, then uses the actual local character loader to enter the same hero and difficulty. Offline sessions only.

Fixes: the old custom PausePanelMessage action was discarded by the layout parser. The button now uses the registered PanelManager/OpenPanel route, intercepted by HUD. Offline mode/list mappings and the game-entry routine are corrected. MainMenuPanel is used to detect frontend readiness.

Validation: native registered panel-message dispatch, native ExitGame dispatch, actual offline loader selecting the offline character list and preserving hero identity for Normal/Nightmare/Hell, invalid selection refusal, signature/hook lifecycle, offline/identity/teardown/timeout guards, and layout upgrade/idempotence. Game creation and profile/file boundaries are stubbed in tests; full live acceptance is still needed.

No launcher or D2R.exe file edits are included.
DLL SHA256: F1B2BA052123BDC1CEB428511AC94D04CA31D116A1B5E1E2A9D0EE66EC988AF2

Updated: compact item-anchored quantity popup, and Restart Game hidden in TCP/IP sessions.

Quantity panel: visual Keep -> New stack item preview, with both quantities. Approximately 307 x 213 at 1080p.

D2RHUD Options > Quantity Right-Clicks > Minimalist Quantity Popup restores the compact 281 x 114 layout without item images. Defaults off; saves immediately. Both layouts retain the 30% text/control enlargement.
