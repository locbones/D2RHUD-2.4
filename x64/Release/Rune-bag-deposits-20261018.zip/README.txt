D2RHUD mixed rune storage-bag deposits - 2026-10-18

Close D2R completely and replace d2rhud.dll beside D2R.exe. Relaunch the mod normally. No recipe/mod-table edits or extra option are needed. The game host needs this build for multiplayer.

For local/custom HUD builds, enable the launcher's existing "Disable update checks" setting before launching (Settings > Launch / Debug > Debug Options). Otherwise its updater can overwrite this DLL with the older public release. Verify the installed DLL against the SHA256 below if it is replaced. No launcher binary modification is required.

Cube exactly one Z01 Storage Bag with any mixture of runes. Their loaded single-rune recipe values are added to the bag's four rune-point tiers, and native useitem consumes the runes while retaining the original bag. Keep the single-rune deposit rows as the value definitions. Inputs containing other item types or additional bags use normal recipe matching. A missing/conflicting definition or capacity overflow refuses the whole deposit.

Existing mapping events (including Blank suppression during Plentiful Pirating), persistent summons, Assassin restart, Whirlwind gold pickup, Terror Zone rotation and other HUD features are retained. No launcher or game executable edits are included.

Validation: mixed/identical/custom multi-stat runes, actual exported 36-rune mod tables, stack quantities, large totals, capacity/scope checks, failed saves/placement rollback, actual native useitem output selection and rune destruction, native saved-stat serialization and hook lifecycle. Inventory/network boundaries are stubbed in native tests. In-game acceptance is still needed; check a mixed deposit then save/exit/reload.

See rune-bag-deposits.md for details.
DLL SHA256: 0C3D8F608962047E95317E64E7375AA8B6B45F1D23BAE569C491D0D6F6DFEE06
