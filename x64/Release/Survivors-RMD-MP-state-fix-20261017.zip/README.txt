Survivors state table fix for RMD-MP

This package contains the complete working RMD-MP states.txt (260 rows),
including hud_cube_map at ID 259, aura=1, and nosend blank.

1. Fully close D2R.
2. Back up your existing file:
   X:\Pandemonium\D2R\Mods\RMD-MP\RMD-MP.mpq\data\global\excel\states.txt
3. Extract this ZIP into X:\Pandemonium\D2R and replace that states.txt.
   The ZIP already includes the Mods\RMD-MP\RMD-MP.mpq folder layout.
4. Relaunch the same RMD-MP mod through the usual HUD startup launcher with
   -txt enabled. The game regenerates the compiled states table from this source.
5. Approach Charsi in Act 1 and try Enter Sanctuary Survivors.

All participating players need the same state table/IDs and current HUD build.
The updated DLL is separate; this package only supplies the required mod table.
No executable, launcher or character save files are included or changed.
